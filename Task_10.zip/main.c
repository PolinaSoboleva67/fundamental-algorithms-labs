#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include "functions.h"

#define LINE_MAX 512

static void stripNewline(char *s)
{
    size_t n = strlen(s);
    while (n > 0 && (s[n - 1] == '\n' || s[n - 1] == '\r')) {
        s[--n] = '\0';
    }
}

int main(void)
{
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);

    char line[LINE_MAX];

    printf("Введите основание системы счисления (2..36): ");
    if (fgets(line, sizeof line, stdin) == NULL) {
        printf("Не удалось прочитать ввод\n");
        return 1;
    }
    stripNewline(line);

    long long base_ll = 0;
    status_t st = parseNumberBase(line, 10, &base_ll);
    if (st != ST_OK || base_ll < 2 || base_ll > 36) {
        printf("Неверное основание, нужно от 2 до 36\n");
        return 1;
    }
    int base = (int)base_ll;

    long long sum = 0;
    long long max_abs = 0;
    int has_numbers = 0;
    int had_overflow = 0;

    printf("Вводите числа (или Stop для завершения):\n");

    while (fgets(line, sizeof line, stdin) != NULL) {
        stripNewline(line);
        if (strcmp(line, "Stop") == 0) break;
        if (*line == '\0') continue;

        long long v;
        st = parseNumberBase(line, base, &v);
        if (st == ST_ERR_INVALID_INPUT) {
            printf("Некорректное число, пропускаю: %s\n", line);
            continue;
        }
        if (st == ST_ERR_OVERFLOW) {
            printf("Число не помещается в long long, пропускаю: %s\n", line);
            continue;
        }

        long long new_sum;
        if (addWithOverflow(sum, v, &new_sum) != ST_OK) {
            had_overflow = 1;
        } else {
            sum = new_sum;
        }

        unsigned long long av = (v < 0)
            ? (0ULL - (unsigned long long)v)
            : (unsigned long long)v;
        if (!has_numbers || av > (unsigned long long)max_abs) {
            max_abs = (long long)av;
        }
        has_numbers = 1;
    }

    if (!has_numbers) {
        printf("Не введено ни одного корректного числа\n");
        return 1;
    }

    int bases[4] = { 9, 18, 27, 36 };
    char buf[80];

    printf("\nСумма всех чисел:\n");
    if (had_overflow) {
        printf("  (переполнение при подсчёте, показано частичное значение)\n");
    }
    printf("  в десятичной: %lld\n", sum);
    for (int i = 0; i < 4; ++i) {
        if (toBaseString(sum, bases[i], buf, sizeof buf) == ST_OK) {
            printf("  в системе %2d: %s\n", bases[i], buf);
        }
    }

    printf("\nМаксимальное по модулю число:\n");
    printf("  в десятичной: %lld\n", max_abs);
    for (int i = 0; i < 4; ++i) {
        if (toBaseString(max_abs, bases[i], buf, sizeof buf) == ST_OK) {
            printf("  в системе %2d: %s\n", bases[i], buf);
        }
    }

    return 0;
}