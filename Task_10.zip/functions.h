#ifndef TASK10_FUNCTIONS_H
#define TASK10_FUNCTIONS_H

#include <stddef.h>

typedef enum {
    ST_OK = 0,
    ST_ERR_INVALID_INPUT,
    ST_ERR_OVERFLOW,
    ST_ERR_NO_NUMBERS
} status_t;

int charToVal(int c);
char valToChar(int v);
status_t parseNumberBase(const char *s, int base, long long *out);
status_t addWithOverflow(long long a, long long b, long long *out);
status_t toBaseString(long long num, int base, char *out, size_t cap);

#endif