#include "functions.h"
#include <limits.h>
#include <stddef.h>

int charToVal(int c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'Z') return c - 'A' + 10;
    if (c >= 'a' && c <= 'z') return c - 'a' + 10;
    return -1;
}

char valToChar(int v)
{
    return (v < 10) ? (char)('0' + v) : (char)('A' + v - 10);
}

status_t parseNumberBase(const char *s, int base, long long *out)
{
    if (s == NULL || out == NULL || *s == '\0') return ST_ERR_INVALID_INPUT;
    if (base < 2 || base > 36)                  return ST_ERR_INVALID_INPUT;

    int sign = 1;
    size_t i = 0;
    if (s[0] == '+' || s[0] == '-') {
        sign = (s[0] == '-') ? -1 : 1;
        i = 1;
    }
    if (s[i] == '\0') return ST_ERR_INVALID_INPUT;

    unsigned long long limit = (sign == 1)
        ? (unsigned long long)LLONG_MAX
        : (unsigned long long)LLONG_MAX + 1ULL;

    unsigned long long acc = 0;
    for (; s[i] != '\0'; ++i) {
        int v = charToVal((unsigned char)s[i]);
        if (v < 0 || v >= base) return ST_ERR_INVALID_INPUT;
        if (acc > (limit - (unsigned)v) / (unsigned)base) return ST_ERR_OVERFLOW;
        acc = acc * (unsigned)base + (unsigned)v;
    }

    if (sign == 1) {
        *out = (long long)acc;
    } else if (acc == (unsigned long long)LLONG_MAX + 1ULL) {
        *out = LLONG_MIN;
    } else {
        *out = -(long long)acc;
    }
    return ST_OK;
}

status_t addWithOverflow(long long a, long long b, long long *out)
{
    if (out == NULL) return ST_ERR_INVALID_INPUT;

    if (b > 0 && a > LLONG_MAX - b) return ST_ERR_OVERFLOW;
    if (b < 0 && a < LLONG_MIN - b) return ST_ERR_OVERFLOW;

    *out = a + b;
    return ST_OK;
}

status_t toBaseString(long long num, int base, char *out, size_t cap)
{
    if (out == NULL || cap < 2) return ST_ERR_INVALID_INPUT;
    if (base < 2 || base > 36)  return ST_ERR_INVALID_INPUT;

    char tmp[80];
    int len = 0;
    int neg = (num < 0);

    unsigned long long u = neg
        ? (0ULL - (unsigned long long)num)
        : (unsigned long long)num;

    if (u == 0) {
        tmp[len++] = '0';
    } else {
        while (u != 0 && len < (int)sizeof tmp) {
            tmp[len++] = valToChar((int)(u % (unsigned)base));
            u /= (unsigned)base;
        }
    }

    size_t p = 0;
    if (neg && p < cap - 1) out[p++] = '-';

    for (int i = len - 1; i >= 0; --i) {
        if (p >= cap - 1) return ST_ERR_INVALID_INPUT;
        out[p++] = tmp[i];
    }
    out[p] = '\0';
    return ST_OK;
}