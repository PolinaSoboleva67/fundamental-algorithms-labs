#ifndef TASK3_FUNCTIONS_H
#define TASK3_FUNCTIONS_H

#include <stddef.h>

typedef enum {
    ST_OK = 0,
    ST_ERR_INVALID_INPUT,
    ST_ERR_OVERFLOW,
    ST_ERR_NO_SOLUTION
} status_t;

typedef enum {
    QUAD_NO_ROOTS = 0,
    QUAD_ONE_ROOT,
    QUAD_TWO_ROOTS,
    QUAD_NOT_EQUATION
} quad_kind_t;

status_t solveQuadraticAllPerms(double eps, double a, double b, double c);
status_t checkMultiplicity(long long a, long long b);
status_t checkRightTriangle(double eps, double a, double b, double c);

#endif