#include "functions.h"
#include <stdio.h>
#include <math.h>

static int dblEq(double x, double y, double eps)
{
    return fabs(x - y) < eps;
}

static void solveOne(double eps, double a, double b, double c)
{
    printf("a=%.2f b=%.2f c=%.2f : ", a, b, c);

    if (dblEq(a, 0.0, eps)) {
        if (dblEq(b, 0.0, eps)) {
            printf("не является уравнением\n");
        } else {
            printf("%lf\n", -c / b);
        }
        return;
    }

    double D = b * b - 4.0 * a * c;

    if (D > eps) {
        double sq = sqrt(D);
        printf("%lf %lf\n", (-b + sq) / (2.0 * a), (-b - sq) / (2.0 * a));
    } else if (fabs(D) < eps) {
        printf("%lf\n", -b / (2.0 * a));
    } else {
        printf("нет корней\n");
    }
}

status_t solveQuadraticAllPerms(double eps, double a, double b, double c)
{
    if (eps <= 0.0) return ST_ERR_INVALID_INPUT;

    double p[6][3] = {
        {a, b, c}, {a, c, b},
        {b, a, c}, {b, c, a},
        {c, a, b}, {c, b, a}
    };

    for (int i = 0; i < 6; ++i) {
        int dup = 0;
        for (int j = 0; j < i; ++j) {
            if (dblEq(p[i][0], p[j][0], eps) &&
                dblEq(p[i][1], p[j][1], eps) &&
                dblEq(p[i][2], p[j][2], eps)) {
                dup = 1;
                break;
            }
        }
        if (!dup) {
            solveOne(eps, p[i][0], p[i][1], p[i][2]);
        }
    }
    return ST_OK;
}

status_t checkMultiplicity(long long a, long long b)
{
    if (a == 0 || b == 0) return ST_ERR_INVALID_INPUT;

    if (a % b == 0) {
        printf("%lld кратно %lld\n", a, b);
    } else {
        printf("%lld не кратно %lld\n", a, b);
    }
    return ST_OK;
}

status_t checkRightTriangle(double eps, double a, double b, double c)
{
    if (eps <= 0.0)                       return ST_ERR_INVALID_INPUT;
    if (a <= 0.0 || b <= 0.0 || c <= 0.0) return ST_ERR_INVALID_INPUT;

    int ok = dblEq(a*a + b*b, c*c, eps) ||
             dblEq(a*a + c*c, b*b, eps) ||
             dblEq(b*b + c*c, a*a, eps);

    printf("%s\n", ok ? "может быть прямоугольным треугольником"
                      : "не может быть прямоугольным треугольником");
    return ST_OK;
}