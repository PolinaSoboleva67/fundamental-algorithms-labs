#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <windows.h>
#include "functions.h"

static status_t parseLongLong(const char *s, long long *out)
{
    if (s == NULL || out == NULL || *s == '\0') return ST_ERR_INVALID_INPUT;

    int sign = 1;
    size_t i = 0;
    if (s[0] == '+' || s[0] == '-') {
        sign = (s[0] == '-') ? -1 : 1;
        i = 1;
    }
    if (s[i] == '\0') return ST_ERR_INVALID_INPUT;

    unsigned long long limit = (sign == 1)
        ? (unsigned long long)LLONG_MAX
        : (unsigned long long)LLONG_MAX + 1ULL;

    unsigned long long acc = 0;
    for (; s[i] != '\0'; ++i) {
        if (s[i] < '0' || s[i] > '9') return ST_ERR_INVALID_INPUT;
        unsigned d = (unsigned)(s[i] - '0');
        if (acc > (limit - d) / 10ULL) return ST_ERR_OVERFLOW;
        acc = acc * 10ULL + d;
    }

    if (sign == 1) {
        *out = (long long)acc;
    } else if (acc == (unsigned long long)LLONG_MAX + 1ULL) {
        *out = LLONG_MIN;
    } else {
        *out = -(long long)acc;
    }
    return ST_OK;
}

static status_t parseDouble(const char *s, double *out)
{
    if (s == NULL || out == NULL || *s == '\0') return ST_ERR_INVALID_INPUT;

    char *end = NULL;
    double v = strtod(s, &end);

    if (end == s || *end != '\0') return ST_ERR_INVALID_INPUT;
    if (v != v) return ST_ERR_INVALID_INPUT;
    if (v > 1e308 || v < -1e308) return ST_ERR_OVERFLOW;

    *out = v;
    return ST_OK;
}

static status_t parseFlag(const char *arg, char *out)
{
    if (arg == NULL || out == NULL) return ST_ERR_INVALID_INPUT;
    if (strlen(arg) != 2)           return ST_ERR_INVALID_INPUT;
    if (arg[0] != '-' && arg[0] != '/') return ST_ERR_INVALID_INPUT;

    switch (arg[1]) {
        case 'q': case 'm': case 't':
            *out = arg[1];
            return ST_OK;
        default:
            return ST_ERR_INVALID_INPUT;
    }
}

static void printUsage(const char *prog)
{
    printf("Использование:\n");
    printf("  %s -q <eps> <a> <b> <c>   квадратное уравнение во всех перестановках\n", prog);
    printf("  %s -m <a> <b>             кратно ли a числу b (оба ненулевые)\n", prog);
    printf("  %s -t <eps> <a> <b> <c>   прямоугольный ли треугольник\n", prog);
}

static int runQ(int argc, char *argv[])
{
    if (argc != 6) {
        printf("Флаг -q требует 4 аргумента: eps, a, b, c\n");
        return 1;
    }
    double eps, a, b, c;
    status_t st;
    if ((st = parseDouble(argv[2], &eps)) != ST_OK ||
        (st = parseDouble(argv[3], &a))   != ST_OK ||
        (st = parseDouble(argv[4], &b))   != ST_OK ||
        (st = parseDouble(argv[5], &c))   != ST_OK) {
        printf("Неверный формат числа\n");
        return 1;
    }
    if (eps <= 0.0) {
        printf("Эпсилон должен быть больше нуля\n");
        return 1;
    }
    solveQuadraticAllPerms(eps, a, b, c);
    return 0;
}

static int runM(int argc, char *argv[])
{
    if (argc != 4) {
        printf("Флаг -m требует 2 аргумента: a, b\n");
        return 1;
    }
    long long a, b;
    status_t st;
    if ((st = parseLongLong(argv[2], &a)) != ST_OK ||
        (st = parseLongLong(argv[3], &b)) != ST_OK) {
        printf("Неверный формат числа\n");
        return 1;
    }
    if (checkMultiplicity(a, b) != ST_OK) {
        printf("Оба числа должны быть ненулевыми\n");
        return 1;
    }
    return 0;
}

static int runT(int argc, char *argv[])
{
    if (argc != 6) {
        printf("Флаг -t требует 4 аргумента: eps, a, b, c\n");
        return 1;
    }
    double eps, a, b, c;
    status_t st;
    if ((st = parseDouble(argv[2], &eps)) != ST_OK ||
        (st = parseDouble(argv[3], &a))   != ST_OK ||
        (st = parseDouble(argv[4], &b))   != ST_OK ||
        (st = parseDouble(argv[5], &c))   != ST_OK) {
        printf("Неверный формат числа\n");
        return 1;
    }
    if (eps <= 0.0) {
        printf("Эпсилон должен быть больше нуля\n");
        return 1;
    }
    if (checkRightTriangle(eps, a, b, c) != ST_OK) {
        printf("Все стороны должны быть положительными\n");
        return 1;
    }
    return 0;
}

int main(int argc, char *argv[])
{
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);

    if (argc < 2) {
        printUsage(argv[0]);
        return 1;
    }

    char flag = 0;
    if (parseFlag(argv[1], &flag) != ST_OK) {
        printf("Неизвестный флаг\n");
        printUsage(argv[0]);
        return 1;
    }

    switch (flag) {
        case 'q': return runQ(argc, argv);
        case 'm': return runM(argc, argv);
        case 't': return runT(argc, argv);
        default:  return 1;
    }
}