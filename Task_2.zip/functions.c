#include "functions.h"
#include <math.h>
#include <stdlib.h>

#define MAX_ITERATIONS 5000000
#define GAMMA_LIMIT_MAX_ITER 200000

static int checkEps(double eps)
{
    return (eps > 0.0) && isfinite(eps);
}

int calculateELimit(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double prev = 0.0, cur = 2.0;
    long n = 1;
    while (fabs(prev - cur) >= eps) {
        prev = cur;
        ++n;
        cur = pow(1.0 + 1.0 / (double)n, (double)n);
        if (n > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = cur;
    return CALC_OK;
}

int calculateESeries(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double cur = 1.0, term = 1.0, prev = 0.0;
    long n = 0;
    while (fabs(prev - cur) >= eps) {
        prev = cur;
        ++n;
        term /= (double)n;
        cur += term;
        if (n > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = cur;
    return CALC_OK;
}

int calculateEEquation(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double cur = 1.0, prev = 0.0;
    long n = 0;
    while (fabs(cur - prev) >= eps) {
        prev = cur;
        cur = cur * (2.0 - log(cur));
        ++n;
        if (n > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = cur;
    return CALC_OK;
}

int calculatePiLimit(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double prev = 0.0, cur = 4.0;
    long n = 1;
    while (fabs(prev - cur) >= eps) {
        prev = cur;
        cur *= 4.0 * n * (n + 1.0) / ((2.0 * n + 1.0) * (2.0 * n + 1.0));
        ++n;
        if (n > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = cur;
    return CALC_OK;
}

int calculatePiSeries(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double cur = 1.0, prev = 0.0;
    double sign = 1.0;
    long n = 2;
    while (4.0 * fabs(prev - cur) >= eps) {
        prev = cur;
        sign = -sign;
        cur += sign / (2.0 * n - 1.0);
        ++n;
        if (n > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = 4.0 * cur;
    return CALC_OK;
}

int calculatePiEquation(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double cur = 1.0, prev = 0.0;
    long n = 0;
    while (fabs(cur - prev) >= eps) {
        prev = cur;
        cur = cur + (cos(cur) + 1.0) / sin(cur);
        ++n;
        if (n > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = cur;
    return CALC_OK;
}

int calculateLn2Limit(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double prev = 0.0, cur = 1.0;
    long n = 1;
    while (fabs(prev - cur) >= eps) {
        prev = cur;
        ++n;
        cur = n * (pow(2.0, 1.0 / (double)n) - 1.0);
        if (n > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = cur;
    return CALC_OK;
}

int calculateLn2Series(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double cur = 1.0, prev = 0.0;
    double sign = 1.0;
    long n = 2;
    while (fabs(prev - cur) >= eps) {
        prev = cur;
        sign = -sign;
        cur += sign / (double)n;
        ++n;
        if (n > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = cur;
    return CALC_OK;
}

int calculateLn2Equation(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double cur = 1.0, prev = 0.0;
    long n = 0;
    while (fabs(cur - prev) >= eps) {
        prev = cur;
        cur = cur - 1.0 + 2.0 / exp(cur);
        ++n;
        if (n > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = cur;
    return CALC_OK;
}

int calculateSqrt2Limit(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double prev = -0.5;
    double cur = prev - prev * prev / 2.0 + 1.0;
    long n = 1;
    while (fabs(prev - cur) >= eps) {
        prev = cur;
        cur = cur - cur * cur / 2.0 + 1.0;
        ++n;
        if (n > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = cur;
    return CALC_OK;
}

int calculateSqrt2Series(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double cur = 1.0, prev = 0.0;
    long k = 2;
    double e = 0.25;
    while (fabs(prev - cur) >= eps) {
        prev = cur;
        cur *= pow(2.0, e);
        e /= 2.0;
        ++k;
        if (k > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = cur;
    return CALC_OK;
}

int calculateSqrt2Equation(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double cur = 1.0, prev = 0.0;
    long k = 0;
    while (fabs(cur - prev) >= eps) {
        prev = cur;
        cur = cur / 2.0 + 1.0 / cur;
        ++k;
        if (k > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = cur;
    return CALC_OK;
}

static long double gammaLimitSum(int m)
{
    long double S = 0.0L;
    long double C = 1.0L;
    long double lnfact = 0.0L;

    for (int k = 1; k <= m; ++k) {
        C = C * (long double)(m - k + 1) / (long double)k;
        lnfact += logl((long double)k);
        long double t = C * lnfact / (long double)k;
        S += (k % 2 == 1) ? -t : t;
    }
    return S;
}

int calculateGammaLimit(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    long double prev = gammaLimitSum(1);
    long double cur  = gammaLimitSum(2);
    int m = 2;

    while (fabsl(prev - cur) >= (long double)eps) {
        prev = cur;
        ++m;
        if (m > GAMMA_LIMIT_MAX_ITER) return ERR_MAX_ITERATIONS;
        cur = gammaLimitSum(m);
    }
    *out = (double)cur;
    return CALC_OK;
}

int calculateGammaSeries(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    double sum = 0.0;
    long k = 2;
    while (1) {
        long s = (long)sqrt((double)k);
        double term = 1.0 / ((double)s * s) - 1.0 / (double)k;
        sum += term;
        if (fabs(term) < eps && k > 10) break;
        ++k;
        if (k > MAX_ITERATIONS) return ERR_MAX_ITERATIONS;
    }
    *out = sum - M_PI * M_PI / 6.0;
    return CALC_OK;
}

static char *buildSieve(long n)
{
    if (n < 2) n = 2;
    char *sieve = (char *)calloc((size_t)n + 1, 1);
    if (sieve == NULL) return NULL;

    for (long i = 2; i <= n / i; ++i) {
        if (sieve[i] == 0) {
            for (long j = i * i; j <= n; j += i) {
                sieve[j] = 1;
            }
        }
    }
    return sieve;
}

#define GAMMA_EQ_MIN_SIEVE 1000000
#define GAMMA_EQ_MAX_SIEVE 50000000

int calculateGammaEquation(double eps, double *out)
{
    if (out == NULL || !checkEps(eps)) return ERR_INVALID_INPUT;

    long sieveSize = (long)(1.0 / eps);
    if (sieveSize < GAMMA_EQ_MIN_SIEVE) sieveSize = GAMMA_EQ_MIN_SIEVE;
    if (sieveSize > GAMMA_EQ_MAX_SIEVE) return ERR_MAX_ITERATIONS;

    char *sieve = buildSieve(sieveSize);
    if (sieve == NULL) return ERR_NO_MEMORY;

    double prev = 0.0, cur = 0.0;
    double prod = 1.0;

    for (long t = 2; t <= sieveSize; ++t) {
        prev = cur;
        if (sieve[t] == 0) {
            prod *= ((double)t - 1.0) / (double)t;
        }
        double expr = log((double)t) * prod;
        if (expr > 0.0) {
            cur = -log(expr);
        }
        if (t > 100 && fabs(cur - prev) < eps) {
            free(sieve);
            *out = cur;
            return CALC_OK;
        }
    }
    free(sieve);
    return ERR_MAX_ITERATIONS;
}