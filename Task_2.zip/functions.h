#ifndef TASK2_FUNCTIONS_H
#define TASK2_FUNCTIONS_H

typedef enum {
    CALC_OK = 0,
    ERR_INVALID_INPUT,
    ERR_MAX_ITERATIONS,
    ERR_NO_MEMORY
} calc_status_t;

int calculateELimit(double eps, double *out);
int calculateESeries(double eps, double *out);
int calculateEEquation(double eps, double *out);

int calculatePiLimit(double eps, double *out);
int calculatePiSeries(double eps, double *out);
int calculatePiEquation(double eps, double *out);

int calculateLn2Limit(double eps, double *out);
int calculateLn2Series(double eps, double *out);
int calculateLn2Equation(double eps, double *out);

int calculateSqrt2Limit(double eps, double *out);
int calculateSqrt2Series(double eps, double *out);
int calculateSqrt2Equation(double eps, double *out);

int calculateGammaLimit(double eps, double *out);
int calculateGammaSeries(double eps, double *out);
int calculateGammaEquation(double eps, double *out);

#endif