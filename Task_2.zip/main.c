#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <windows.h>
#include "functions.h"

static int parseDouble(const char *arg, double *out)
{
    if (arg == NULL || *arg == '\0' || out == NULL) return ERR_INVALID_INPUT;

    char *end = NULL;
    double v = strtod(arg, &end);
    if (end == arg || *end != '\0') return ERR_INVALID_INPUT;
    if (isnan(v) || isinf(v))       return ERR_INVALID_INPUT;

    *out = v;
    return CALC_OK;
}

int main(int argc, char *argv[])
{
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);

    if (argc != 2) {
        printf("Использование: %s <эпсилон>\n", argv[0]);
        printf("  эпсилон - точность, положительное число меньше 1\n");
        printf("  например: 1e-6\n");
        return 1;
    }

    double eps = 0.0;
    if (parseDouble(argv[1], &eps) != CALC_OK) {
        printf("Неверный формат эпсилона\n");
        return 1;
    }
    if (eps <= 0.0 || eps >= 1.0) {
        printf("Эпсилон должен быть больше 0 и меньше 1\n");
        return 1;
    }

    printf("Точность: %g\n\n", eps);

    printf("Число e:\n");
    {
        double v; int s = calculateELimit(eps, &v);
        if (s == CALC_OK) printf("  предел        %.10f\n", v);
        else              printf("  предел        ошибка\n");
    }
    {
        double v; int s = calculateESeries(eps, &v);
        if (s == CALC_OK) printf("  ряд           %.10f\n", v);
        else              printf("  ряд           ошибка\n");
    }
    {
        double v; int s = calculateEEquation(eps, &v);
        if (s == CALC_OK) printf("  уравнение     %.10f\n", v);
        else              printf("  уравнение     ошибка\n");
    }

    printf("\nЧисло pi:\n");
    {
        double v; int s = calculatePiLimit(eps, &v);
        if (s == CALC_OK) printf("  предел        %.10f\n", v);
        else              printf("  предел        ошибка\n");
    }
    {
        double v; int s = calculatePiSeries(eps, &v);
        if (s == CALC_OK) printf("  ряд           %.10f\n", v);
        else              printf("  ряд           ошибка\n");
    }
    {
        double v; int s = calculatePiEquation(eps, &v);
        if (s == CALC_OK) printf("  уравнение     %.10f\n", v);
        else              printf("  уравнение     ошибка\n");
    }

    printf("\nЧисло ln 2:\n");
    {
        double v; int s = calculateLn2Limit(eps, &v);
        if (s == CALC_OK) printf("  предел        %.10f\n", v);
        else              printf("  предел        ошибка\n");
    }
    {
        double v; int s = calculateLn2Series(eps, &v);
        if (s == CALC_OK) printf("  ряд           %.10f\n", v);
        else              printf("  ряд           ошибка\n");
    }
    {
        double v; int s = calculateLn2Equation(eps, &v);
        if (s == CALC_OK) printf("  уравнение     %.10f\n", v);
        else              printf("  уравнение     ошибка\n");
    }

    printf("\nЧисло sqrt(2):\n");
    {
        double v; int s = calculateSqrt2Limit(eps, &v);
        if (s == CALC_OK) printf("  предел        %.10f\n", v);
        else              printf("  предел        ошибка\n");
    }
    {
        double v; int s = calculateSqrt2Series(eps, &v);
        if (s == CALC_OK) printf("  ряд           %.10f\n", v);
        else              printf("  ряд           ошибка\n");
    }
    {
        double v; int s = calculateSqrt2Equation(eps, &v);
        if (s == CALC_OK) printf("  уравнение     %.10f\n", v);
        else              printf("  уравнение     ошибка\n");
    }

    printf("\nПостоянная Эйлера-Маскерони:\n");
    {
        double v; int s = calculateGammaLimit(eps, &v);
        if (s == CALC_OK) printf("  предел        %.10f\n", v);
        else              printf("  предел        ошибка\n");
    }
    {
        double v; int s = calculateGammaSeries(eps, &v);
        if (s == CALC_OK) printf("  ряд           %.10f\n", v);
        else              printf("  ряд           ошибка\n");
    }
    {
        double v; int s = calculateGammaEquation(eps, &v);
        if (s == CALC_OK) printf("  уравнение     %.10f\n", v);
        else              printf("  уравнение     ошибка\n");
    }

    return 0;
}