#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <limits.h>
#include <windows.h>
#include "functions.h"

static status_t parseInt(const char *s, int *out)
{
    if (s == NULL || out == NULL || *s == '\0') return ST_ERR_INVALID_INPUT;

    int sign = 1;
    size_t i = 0;
    if (s[0] == '+' || s[0] == '-') {
        sign = (s[0] == '-') ? -1 : 1;
        i = 1;
    }
    if (s[i] == '\0') return ST_ERR_INVALID_INPUT;

    long long limit = (sign == 1) ? (long long)INT_MAX : (-(long long)INT_MIN);
    long long acc = 0;
    for (; s[i] != '\0'; ++i) {
        if (s[i] < '0' || s[i] > '9') return ST_ERR_INVALID_INPUT;
        acc = acc * 10 + (s[i] - '0');
        if (acc > limit) return ST_ERR_INVALID_INPUT;
    }
    *out = (int)(sign * acc);
    return ST_OK;
}

static void printArray(const char *label, const int *a, size_t n)
{
    printf("%s: ", label);
    for (size_t i = 0; i < n; ++i) printf("%d ", a[i]);
    printf("\n");
}

static void printUsage(const char *prog)
{
    printf("Использование: %s <a> <b>\n", prog);
    printf("  a, b — границы диапазона для генерации (a <= b)\n");
}

int main(int argc, char *argv[])
{
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);

    if (argc != 3) {
        printUsage(argv[0]);
        return 1;
    }

    int a = 0, b = 0;
    if (parseInt(argv[1], &a) != ST_OK || parseInt(argv[2], &b) != ST_OK) {
        printf("Неверный формат числа\n");
        return 1;
    }
    if (a > b) {
        printf("Нижняя граница должна быть не больше верхней\n");
        return 1;
    }

    srand((unsigned)time(NULL));

    printf("=== Часть 1: фиксированный массив ===\n");
    int fixed[FIXED_SIZE];
    if (fillRandom(fixed, FIXED_SIZE, a, b) != ST_OK) {
        printf("Ошибка заполнения массива\n");
        return 1;
    }
    printArray("До обмена   ", fixed, FIXED_SIZE);

    if (swapMinMaxOnePass(fixed, FIXED_SIZE) != ST_OK) {
        printf("Ошибка обмена\n");
        return 1;
    }
    printArray("После обмена", fixed, FIXED_SIZE);

    printf("\n=== Часть 2: динамические массивы ===\n");

    size_t na = 0, nb = 0;
    if (randSize(10, 10000, &na) != ST_OK || randSize(10, 10000, &nb) != ST_OK) {
        printf("Ошибка генерации размера\n");
        return 1;
    }

    int *A = (int *)malloc(na * sizeof(int));
    int *B = (int *)malloc(nb * sizeof(int));
    int *C = (int *)malloc(na * sizeof(int));

    if (A == NULL || B == NULL || C == NULL) {
        free(A);
        free(B);
        free(C);
        printf("Ошибка выделения памяти\n");
        return 1;
    }

    if (fillRandom(A, na, -1000, 1000) != ST_OK ||
        fillRandom(B, nb, -1000, 1000) != ST_OK) {
        free(A); free(B); free(C);
        printf("Ошибка заполнения динамических массивов\n");
        return 1;
    }

    if (makeArrayC(A, na, B, nb, C) != ST_OK) {
        free(A); free(B); free(C);
        printf("Ошибка формирования массива C\n");
        return 1;
    }

    printf("Размер A = %llu\n", (unsigned long long)na);
    printf("Размер B = %llu\n", (unsigned long long)nb);

    printArray("A", A, na);
    printArray("B", B, nb);
    printArray("C", C, na);

    free(A);
    free(B);
    free(C);
    return 0;
}