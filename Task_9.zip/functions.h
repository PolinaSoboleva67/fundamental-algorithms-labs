#ifndef TASK9_FUNCTIONS_H
#define TASK9_FUNCTIONS_H

#include <stddef.h>

typedef enum {
    ST_OK = 0,
    ST_ERR_INVALID_INPUT,
    ST_ERR_BAD_RANGE,
    ST_ERR_ALLOC
} status_t;

#define FIXED_SIZE 20

status_t fillRandom(int *arr, size_t n, int lo, int hi);
status_t swapMinMaxOnePass(int *arr, size_t n);
status_t makeArrayC(const int *A, size_t na,
                    const int *B, size_t nb,
                    int *C);
status_t randSize(size_t min, size_t max, size_t *out);

#endif