#include "functions.h"
#include <stdlib.h>
#include <limits.h>

static int randInRange(int lo, int hi)
{
    long long range = (long long)hi - (long long)lo + 1LL;
    return lo + (int)(rand() % range);
}

status_t fillRandom(int *arr, size_t n, int lo, int hi)
{
    if (arr == NULL) return ST_ERR_INVALID_INPUT;
    if (lo > hi)     return ST_ERR_BAD_RANGE;

    for (size_t i = 0; i < n; ++i) {
        arr[i] = randInRange(lo, hi);
    }
    return ST_OK;
}

status_t swapMinMaxOnePass(int *arr, size_t n)
{
    if (arr == NULL || n == 0) return ST_ERR_INVALID_INPUT;

    size_t i_min = 0, i_max = 0;
    for (size_t i = 1; i < n; ++i) {
        if (arr[i] < arr[i_min]) i_min = i;
        if (arr[i] > arr[i_max]) i_max = i;
    }

    int t = arr[i_min];
    arr[i_min] = arr[i_max];
    arr[i_max] = t;
    return ST_OK;
}

status_t makeArrayC(const int *A, size_t na,
                    const int *B, size_t nb,
                    int *C)
{
    if (A == NULL || B == NULL || C == NULL) return ST_ERR_INVALID_INPUT;
    if (na == 0 || nb == 0)                  return ST_ERR_INVALID_INPUT;

    for (size_t i = 0; i < na; ++i) {
        int best = B[0];
        long long best_diff = llabs((long long)A[i] - (long long)B[0]);

        for (size_t j = 1; j < nb; ++j) {
            long long d = llabs((long long)A[i] - (long long)B[j]);
            if (d < best_diff) {
                best_diff = d;
                best = B[j];
            }
        }

        long long sum = (long long)A[i] + (long long)best;
        if (sum > INT_MAX) sum = INT_MAX;
        if (sum < INT_MIN) sum = INT_MIN;
        C[i] = (int)sum;
    }
    return ST_OK;
}

status_t randSize(size_t min, size_t max, size_t *out)
{
    if (out == NULL)   return ST_ERR_INVALID_INPUT;
    if (min > max)     return ST_ERR_BAD_RANGE;
    if (max == 0)      return ST_ERR_BAD_RANGE;

    unsigned long long range = (unsigned long long)(max - min + 1ULL);
    *out = min + (size_t)((unsigned long long)rand() % range);
    return ST_OK;
}