#include <stdio.h>
#include <string.h>
#include <windows.h>
#include "functions.h"

#define PATH_MAX 4096

static status_t parseFlag(const char *arg, char *op, int *has_n)
{
    if (arg == NULL || op == NULL || has_n == NULL) return ST_ERR_INVALID_INPUT;

    size_t len = strlen(arg);
    if (len < 2 || len > 3) return ST_ERR_INVALID_INPUT;
    if (arg[0] != '-' && arg[0] != '/') return ST_ERR_INVALID_INPUT;

    if (arg[1] == 'n') {
        if (len != 3) return ST_ERR_INVALID_INPUT;
        *has_n = 1;
        *op = arg[2];
    } else {
        if (len != 2) return ST_ERR_INVALID_INPUT;
        *has_n = 0;
        *op = arg[1];
    }

    if (*op != 'd' && *op != 'i' && *op != 's' && *op != 'a')
        return ST_ERR_INVALID_INPUT;

    return ST_OK;
}

static void printUsage(const char *prog)
{
    printf("Использование:\n");
    printf("  %s -d  <входной файл>\n", prog);
    printf("  %s -i  <входной файл>\n", prog);
    printf("  %s -s  <входной файл>\n", prog);
    printf("  %s -a  <входной файл>\n", prog);
    printf("  %s -nd <входной> <выходной>\n", prog);
    printf("  %s -ni <входной> <выходной>\n", prog);
    printf("  %s -ns <входной> <выходной>\n", prog);
    printf("  %s -na <входной> <выходной>\n", prog);
}

int main(int argc, char *argv[])
{
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);

    if (argc < 3 || argc > 4) {
        printUsage(argv[0]);
        return 1;
    }

    char op = 0;
    int has_n = 0;
    if (parseFlag(argv[1], &op, &has_n) != ST_OK) {
        printf("Неверный флаг\n");
        printUsage(argv[0]);
        return 1;
    }

    if (has_n && argc != 4) {
        printf("Флаг с 'n' требует путь к выходному файлу\n");
        return 1;
    }
    if (!has_n && argc != 3) {
        printf("Лишние аргументы\n");
        return 1;
    }

    const char *in_path = argv[2];
    char out_path[PATH_MAX];

    if (has_n) {
        if (strlen(argv[3]) >= sizeof out_path) {
            printf("Путь к выходному файлу слишком длинный\n");
            return 1;
        }
        strcpy(out_path, argv[3]);
    } else {
        if (strlen(in_path) + 5 >= sizeof out_path) {
            printf("Путь к входному файлу слишком длинный\n");
            return 1;
        }
        strcpy(out_path, "out_");
        strcat(out_path, in_path);
    }

    char nin[PATH_MAX], nout[PATH_MAX];
    if (normalizePath(in_path, nin, sizeof nin) != ST_OK ||
        normalizePath(out_path, nout, sizeof nout) != ST_OK) {
        printf("Ошибка путей\n");
        return 1;
    }
    if (strcmp(nin, nout) == 0) {
        printf("Входной и выходной файлы совпадают\n");
        return 1;
    }

    FILE *fin = fopen(in_path, "r");
    if (fin == NULL) {
        printf("Не удалось открыть входной файл\n");
        return 1;
    }
    FILE *fout = fopen(out_path, "w");
    if (fout == NULL) {
        fclose(fin);
        printf("Не удалось открыть выходной файл\n");
        return 1;
    }

    status_t st;
    switch (op) {
        case 'd': st = flagD(fin, fout); break;
        case 'i': st = flagI(fin, fout); break;
        case 's': st = flagS(fin, fout); break;
        case 'a': st = flagA(fin, fout); break;
        default:  st = ST_ERR_INVALID_INPUT;
    }

    fclose(fin);
    fclose(fout);

    if (st != ST_OK) {
        printf("Ошибка при обработке файла\n");
        return 1;
    }

    printf("Готово: %s\n", out_path);
    return 0;
}