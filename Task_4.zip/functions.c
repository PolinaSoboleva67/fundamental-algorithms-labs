#include "functions.h"
#include <string.h>

static int isLatin(int c)
{
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

static int isDigit(int c)
{
    return c >= '0' && c <= '9';
}

status_t normalizePath(const char *in, char *out, size_t cap)
{
    if (in == NULL || out == NULL || cap < 2) return ST_ERR_INVALID_INPUT;

    char tmp[4096];
    size_t len = strlen(in);
    if (len >= sizeof tmp) return ST_ERR_PATH_TOO_LONG;
    memcpy(tmp, in, len + 1);

    for (size_t i = 0; i < len; ++i) {
        if (tmp[i] == '\\') tmp[i] = '/';
    }

    char *parts[256];
    int n = 0;
    int absolute = (tmp[0] == '/');

    char *save = NULL;
    char *tok = strtok_r(tmp, "/", &save);
    while (tok != NULL && n < 256) {
        if (strcmp(tok, ".") == 0) {
            /* пропускаем */
        } else if (strcmp(tok, "..") == 0) {
            if (n > 0) --n;
            else if (!absolute) parts[n++] = tok;
        } else {
            parts[n++] = tok;
        }
        tok = strtok_r(NULL, "/", &save);
    }

    size_t p = 0;
    if (absolute) {
        if (p < cap - 1) out[p++] = '/';
    }
    for (int i = 0; i < n; ++i) {
        size_t plen = strlen(parts[i]);
        if (p + plen + 2 >= cap) return ST_ERR_PATH_TOO_LONG;
        memcpy(out + p, parts[i], plen);
        p += plen;
        if (i + 1 < n) out[p++] = '/';
    }
    out[p] = '\0';
    return ST_OK;
}

status_t flagD(FILE *fin, FILE *fout)
{
    if (fin == NULL || fout == NULL) return ST_ERR_INVALID_INPUT;

    int c;
    while ((c = fgetc(fin)) != EOF) {
        if (!isDigit(c)) fputc(c, fout);
    }
    return ST_OK;
}

status_t flagI(FILE *fin, FILE *fout)
{
    if (fin == NULL || fout == NULL) return ST_ERR_INVALID_INPUT;

    int c;
    long long count = 0;
    int wrote_any = 0;

    while ((c = fgetc(fin)) != EOF) {
        if (c == '\n') {
            fprintf(fout, "%lld\n", count);
            count = 0;
            wrote_any = 1;
        } else if (isLatin(c)) {
            ++count;
        }
    }
    if (!wrote_any || count > 0) {
        fprintf(fout, "%lld\n", count);
    }
    return ST_OK;
}

status_t flagS(FILE *fin, FILE *fout)
{
    if (fin == NULL || fout == NULL) return ST_ERR_INVALID_INPUT;

    int c;
    long long count = 0;
    int wrote_any = 0;

    while ((c = fgetc(fin)) != EOF) {
        if (c == '\n') {
            fprintf(fout, "%lld\n", count);
            count = 0;
            wrote_any = 1;
        } else if (!isLatin(c) && !isDigit(c) && c != ' ') {
            ++count;
        }
    }
    if (!wrote_any || count > 0) {
        fprintf(fout, "%lld\n", count);
    }
    return ST_OK;
}

status_t flagA(FILE *fin, FILE *fout)
{
    if (fin == NULL || fout == NULL) return ST_ERR_INVALID_INPUT;

    int c;
    while ((c = fgetc(fin)) != EOF) {
        if (isDigit(c)) {
            fputc(c, fout);
        } else {
            fprintf(fout, "%X", (unsigned char)c);
        }
    }
    return ST_OK;
}