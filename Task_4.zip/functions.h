#ifndef TASK4_FUNCTIONS_H
#define TASK4_FUNCTIONS_H

#include <stddef.h>
#include <stdio.h>

typedef enum {
    ST_OK = 0,
    ST_ERR_INVALID_INPUT,
    ST_ERR_PATH_TOO_LONG,
    ST_ERR_SAME_FILE,
    ST_ERR_FILE_OPEN
} status_t;

status_t normalizePath(const char *in, char *out, size_t cap);
status_t flagD(FILE *fin, FILE *fout);
status_t flagI(FILE *fin, FILE *fout);
status_t flagS(FILE *fin, FILE *fout);
status_t flagA(FILE *fin, FILE *fout);

#endif