#include "functions.h"
#include <stdio.h>
#include <stdarg.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

status_t isConvexPolygon(int n, ...)
{
    if (n < 3) return ST_ERR_INVALID_INPUT;

    va_list ap;
    va_start(ap, n);

    double x1 = va_arg(ap, double), y1 = va_arg(ap, double);
    double x2 = va_arg(ap, double), y2 = va_arg(ap, double);
    double x3 = va_arg(ap, double), y3 = va_arg(ap, double);

    double x_first = x1, y_first = y1;
    double x_second = x2, y_second = y2;

    int sign = 0;
    double cross = (x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1);
    if (cross > 0) sign = 1;
    else if (cross < 0) sign = -1;

    for (int i = 1; i < n; ++i) {
        x1 = x2; y1 = y2;
        x2 = x3; y2 = y3;

        if (i == n - 2) {
            x3 = x_first; y3 = y_first;
        } else if (i == n - 1) {
            x3 = x_second; y3 = y_second;
        } else {
            x3 = va_arg(ap, double);
            y3 = va_arg(ap, double);
        }

        cross = (x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1);

        if (cross > 0 && sign < 0) { va_end(ap); return ST_ERR_INVALID_INPUT; }
        if (cross < 0 && sign > 0) { va_end(ap); return ST_ERR_INVALID_INPUT; }
    }

    va_end(ap);
    return ST_OK;
}

status_t evalPolynomial(double x, int n, double *out, ...)
{
    if (out == NULL) return ST_ERR_INVALID_INPUT;
    if (n < 0)       return ST_ERR_INVALID_INPUT;

    va_list ap;
    va_start(ap, out);

    double result = 0.0;
    for (int i = n; i >= 0; --i) {
        double coef = va_arg(ap, double);
        result = result * x + coef;
    }

    va_end(ap);

    if (isnan(result) || isinf(result)) return ST_ERR_OVERFLOW;

    *out = result;
    return ST_OK;
}

static int charToVal(int c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'Z') return c - 'A' + 10;
    if (c >= 'a' && c <= 'z') return c - 'a' + 10;
    return -1;
}

static int isKaprekar(unsigned long long n, int base)
{
    if (n == 0) return 0;

    unsigned long long bd = 1;
    unsigned long long tmp = n;
    while (tmp > 0) {
        bd *= (unsigned long long)base;
        tmp /= (unsigned long long)base;
    }

    unsigned long long sq = n * n;
    if (n != 0 && sq / n != n) return 0;

    unsigned long long right = sq % bd;
    unsigned long long left  = sq / bd;

    return (left + right == n);
}

status_t printKaprekar(int base, ...)
{
    if (base < 2 || base > 36) return ST_ERR_INVALID_INPUT;

    va_list ap;
    va_start(ap, base);

    const char *str;
    while ((str = va_arg(ap, const char *)) != NULL) {
        if (*str == '\0') continue;

        int bad = 0;
        for (const char *p = str; *p; ++p) {
            int v = charToVal((unsigned char)*p);
            if (v < 0 || v >= base) { bad = 1; break; }
        }
        if (bad) continue;

        unsigned long long n = strtoull(str, NULL, base);

        if (isKaprekar(n, base)) {
            printf("%s в системе счисления %d\n", str, base);
        }
    }

    va_end(ap);
    return ST_OK;
}

status_t geometricMean(int n, double *out, ...)
{
    if (out == NULL || n <= 0) return ST_ERR_INVALID_INPUT;

    va_list ap;
    va_start(ap, out);

    double mult = 1.0;
    for (int i = 0; i < n; ++i) {
        double v = va_arg(ap, double);
        if (v < 0) { va_end(ap); return ST_ERR_INVALID_INPUT; }
        mult *= v;
    }

    va_end(ap);

    if (isnan(mult) || isinf(mult)) return ST_ERR_OVERFLOW;

    *out = pow(mult, 1.0 / n);
    return ST_OK;
}

status_t powerInt(double x, int power, double *out)
{
    if (out == NULL) return ST_ERR_INVALID_INPUT;

    if (power == 0) { *out = 1.0; return ST_OK; }

    if (power < 0) {
        double inv;
        status_t st = powerInt(x, -power, &inv);
        if (st != ST_OK) return st;
        if (inv == 0.0) return ST_ERR_NO_SOLUTION;
        *out = 1.0 / inv;
        return ST_OK;
    }

    double half;
    status_t st = powerInt(x, power / 2, &half);
    if (st != ST_OK) return st;

    double res = half * half;
    if (power % 2 != 0) res *= x;

    if (isnan(res) || isinf(res)) return ST_ERR_OVERFLOW;

    *out = res;
    return ST_OK;
}

status_t bisection(double (*f)(double), double a, double b,
                   double eps, double *out)
{
    if (f == NULL || out == NULL)   return ST_ERR_INVALID_INPUT;
    if (eps <= 0.0)                 return ST_ERR_INVALID_INPUT;

    double fa = f(a);
    double fb = f(b);

    if (isnan(fa) || isnan(fb) || isinf(fa) || isinf(fb))
        return ST_ERR_INVALID_INPUT;

    if (fa * fb >= 0.0) return ST_ERR_NO_SOLUTION;

    while (fabs(b - a) > eps) {
        double c = (a + b) / 2.0;
        double fc = f(c);

        if (fa * fc < 0.0) {
            b = c;
            fb = fc;
        } else {
            a = c;
            fa = fc;
        }
    }

    *out = (a + b) / 2.0;
    return ST_OK;
}

double f1(double x) { return x * x - 2.0; }
double f2(double x) { return x * x * x - x - 3.0; }