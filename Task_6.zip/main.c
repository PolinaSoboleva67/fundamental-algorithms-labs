#include <stdio.h>
#include <windows.h>
#include "functions.h"

static void printUsage(void)
{
    printf("Программа демонстрирует шесть функций:\n");
    printf("  1) isConvexPolygon   - выпуклость многоугольника\n");
    printf("  2) evalPolynomial    - значение полинома в точке\n");
    printf("  3) printKaprekar     - числа Капрекара\n");
    printf("  4) geometricMean     - среднее геометрическое\n");
    printf("  5) powerInt          - возведение в степень\n");
    printf("  6) bisection         - корень уравнения\n");
    printf("Аргументы командной строки не требуются.\n");
}

int main(int argc, char *argv[])
{
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);

    (void)argc;
    (void)argv;

    printf("1) Выпуклость многоугольника\n");
    status_t st;

    st = isConvexPolygon(5,
        0.0, 0.0, 5.0, 0.0, 5.0, 4.0, 2.0, 4.0, 2.0, 1.0);
    printf("многоугольник 1: %s\n",
           st == ST_OK ? "выпуклый" : "невыпуклый");

    st = isConvexPolygon(4,
        1.0, 1.0, 5.0, 0.0, 6.0, 4.0, 2.0, 5.0);
    printf("многоугольник 2: %s\n",
           st == ST_OK ? "выпуклый" : "невыпуклый");

    printf("\n2) Значение полинома\n");
    double poly = 0.0;
    st = evalPolynomial(6.0, 3, &poly, 1.0, 0.0, -4.0, 9.0);
    if (st == ST_OK) printf("P(6) = %lf\n", poly);
    else             printf("ошибка вычисления полинома\n");

    printf("\n3) Числа Капрекара\n");
    printf("в системе счисления 10:\n");
    printKaprekar(10, "1", "9", "45", "55", "99", "297", "703", "999", NULL);
    printf("в системе счисления 16:\n");
    printKaprekar(16, "1", "F", "45", "AB", "FF", NULL);

    printf("\n4) Среднее геометрическое\n");
    double gm = 0.0;
    st = geometricMean(3, &gm, 2.0, 4.0, 8.0);
    if (st == ST_OK) printf("(2, 4, 8) -> %lf\n", gm);
    else             printf("ошибка\n");

    st = geometricMean(5, &gm, 5.8, 4.0, 3.9, 168.25, 61.8);
    if (st == ST_OK) printf("(5.8, 4, 3.9, 168.25, 61.8) -> %lf\n", gm);
    else             printf("ошибка\n");

    printf("\n5) Возведение в степень\n");
    double pw = 0.0;
    if (powerInt(1.5, 4, &pw) == ST_OK)   printf("1.5^4 = %lf\n", pw);
    if (powerInt(2.0, -3, &pw) == ST_OK)  printf("2^(-3) = %lf\n", pw);
    if (powerInt(2.0, 0, &pw) == ST_OK)   printf("2^0 = %lf\n", pw);

    printf("\n6) Метод бисекции\n");
    double root = 0.0;
    st = bisection(f1, 1.0, 2.0, 1e-6, &root);
    if (st == ST_OK) printf("корень x^2 - 2 на [1,2]: %lf\n", root);
    else             printf("корень не найден\n");

    st = bisection(f2, 1.0, 2.0, 1e-6, &root);
    if (st == ST_OK) printf("корень x^3 - x - 3 на [1,2]: %lf\n", root);
    else             printf("корень не найден\n");

    return 0;
}