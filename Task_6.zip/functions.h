#ifndef TASK6_FUNCTIONS_H
#define TASK6_FUNCTIONS_H

#include <stddef.h>

typedef enum {
    ST_OK = 0,
    ST_ERR_INVALID_INPUT,
    ST_ERR_OVERFLOW,
    ST_ERR_NO_SOLUTION
} status_t;

status_t isConvexPolygon(int n, ...);
status_t evalPolynomial(double x, int n, double *out, ...);
status_t printKaprekar(int base, ...);
status_t geometricMean(int n, double *out, ...);
status_t powerInt(double x, int power, double *out);
status_t bisection(double (*f)(double), double a, double b,
                   double eps, double *out);

double f1(double x);
double f2(double x);

#endif