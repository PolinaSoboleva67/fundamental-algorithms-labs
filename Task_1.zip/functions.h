#ifndef TASK1_FUNCTIONS_H
#define TASK1_FUNCTIONS_H

#include <stddef.h>

typedef enum {
    ST_OK = 0,
    ST_ERR_INVALID_INPUT,
    ST_ERR_OVERFLOW,
    ST_ERR_NO_RESULT
} status_t;

typedef enum {
    NUM_NEITHER_PRIME_NOR_COMPOSITE = 0,
    NUM_PRIME,
    NUM_COMPOSITE
} primality_t;

#define MULTIPLES_MAX     100
#define HEX_DIGITS_MAX     16
#define POWERS_BASE_MIN     1
#define POWERS_BASE_MAX    10
#define POWERS_POW_MAX     10
#define FACT_MAX_ARG       20

status_t getMultiplesOfX(long long x, int *out, size_t capacity, size_t *count);
status_t checkIfPrime(long long x, primality_t *out);
status_t getHexDigits(long long x, char *out, size_t capacity, size_t *count, int *is_negative);
status_t getTableOfPowers(long long x, long long *out, size_t capacity, size_t *cols);
status_t getSumOfSequence(long long x, long long *out);
status_t getFactorial(long long x, long long *out);

#endif