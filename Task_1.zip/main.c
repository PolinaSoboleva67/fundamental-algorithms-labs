#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <windows.h>
#include "functions.h"

static status_t parseLongLong(const char *s, long long *out)
{
    if (s == NULL || out == NULL || *s == '\0') return ST_ERR_INVALID_INPUT;

    int sign = 1;
    size_t i = 0;
    if (s[0] == '+' || s[0] == '-') {
        sign = (s[0] == '-') ? -1 : 1;
        i = 1;
    }
    if (s[i] == '\0') return ST_ERR_INVALID_INPUT;

    unsigned long long limit = (sign == 1)
        ? (unsigned long long)LLONG_MAX
        : (unsigned long long)LLONG_MAX + 1ULL;

    unsigned long long acc = 0;
    for (; s[i] != '\0'; ++i) {
        if (s[i] < '0' || s[i] > '9') return ST_ERR_INVALID_INPUT;
        unsigned d = (unsigned)(s[i] - '0');
        if (acc > (limit - d) / 10ULL) return ST_ERR_OVERFLOW;
        acc = acc * 10ULL + d;
    }

    if (sign == 1) {
        *out = (long long)acc;
    } else if (acc == (unsigned long long)LLONG_MAX + 1ULL) {
        *out = LLONG_MIN;
    } else {
        *out = -(long long)acc;
    }
    return ST_OK;
}

static status_t parseFlag(const char *arg, char *out)
{
    if (arg == NULL || out == NULL) return ST_ERR_INVALID_INPUT;
    if (strlen(arg) != 2)           return ST_ERR_INVALID_INPUT;
    if (arg[0] != '-' && arg[0] != '/') return ST_ERR_INVALID_INPUT;

    switch (arg[1]) {
        case 'h': case 'p': case 's':
        case 'e': case 'a': case 'f':
            *out = arg[1];
            return ST_OK;
        default:
            return ST_ERR_INVALID_INPUT;
    }
}

static void printUsage(const char *prog)
{
    printf("Использование: %s <число> <-h|-p|-s|-e|-a|-f>\n", prog ? prog : "программа");
    printf("  -h  числа от 1 до 100, кратные числу\n");
    printf("  -p  простое или составное число\n");
    printf("  -s  цифры числа в 16-ричной системе\n");
    printf("  -e  таблица степеней (число от 1 до 10)\n");
    printf("  -a  сумма чисел от 1 до числа\n");
    printf("  -f  факториал числа\n");
}

static int runH(long long x)
{
    int buf[MULTIPLES_MAX];
    size_t n = 0;
    status_t st = getMultiplesOfX(x, buf, MULTIPLES_MAX, &n);
    if (st == ST_ERR_INVALID_INPUT) {
        printf("Число должно быть больше нуля\n");
        return 1;
    }
    if (st != ST_OK) return 1;

    if (n == 0) {
        printf("Нет чисел в диапазоне [1;100], кратных %lld\n", x);
        return 0;
    }
    for (size_t i = 0; i < n; ++i) printf("%d ", buf[i]);
    printf("\n");
    return 0;
}

static int runP(long long x)
{
    primality_t p;
    if (checkIfPrime(x, &p) != ST_OK) {
        printf("Внутренняя ошибка\n");
        return 1;
    }
    switch (p) {
        case NUM_PRIME:     printf("%lld — простое число\n", x); break;
        case NUM_COMPOSITE: printf("%lld — составное число\n", x); break;
        default:            printf("%lld — ни простое, ни составное\n", x); break;
    }
    return 0;
}

static int runS(long long x)
{
    char hex[HEX_DIGITS_MAX];
    size_t n = 0;
    int neg = 0;
    if (getHexDigits(x, hex, HEX_DIGITS_MAX, &n, &neg) != ST_OK) {
        printf("Внутренняя ошибка\n");
        return 1;
    }
    if (neg) printf("- ");
    for (size_t i = 0; i < n; ++i) printf("%c ", hex[i]);
    printf("\n");
    return 0;
}

static int runE(long long x)
{
    long long table[POWERS_BASE_MAX * POWERS_POW_MAX];
    size_t cols = 0;
    status_t st = getTableOfPowers(x, table,
                                   sizeof table / sizeof table[0], &cols);
    if (st == ST_ERR_INVALID_INPUT) {
        printf("Число должно быть в диапазоне от 1 до 10\n");
        return 1;
    }
    if (st != ST_OK) return 1;

    for (int base = POWERS_BASE_MIN; base <= POWERS_BASE_MAX; ++base) {
        for (size_t j = 0; j < cols; ++j) {
            printf("%lld ", table[(base - POWERS_BASE_MIN) * POWERS_POW_MAX + j]);
        }
        printf("\n");
    }
    return 0;
}

static int runA(long long x)
{
    long long sum = 0;
    status_t st = getSumOfSequence(x, &sum);
    if (st == ST_ERR_OVERFLOW) {
        printf("Сумма не помещается в long long (переполнение)\n");
        return 1;
    }
    if (st != ST_OK) {
        printf("Число должно быть не меньше 1\n");
        return 1;
    }
    printf("%lld\n", sum);
    return 0;
}

static int runF(long long x)
{
    long long fact = 0;
    status_t st = getFactorial(x, &fact);
    if (st == ST_ERR_OVERFLOW) {
        printf("Факториал числа %lld не помещается в long long (переполнение)\n", x);
        return 1;
    }
    if (st != ST_OK) {
        printf("Число должно быть не меньше 0\n");
        return 1;
    }
    printf("%lld\n", fact);
    return 0;
}

int main(int argc, char *argv[])
{
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);

    if (argc != 3) {
        printUsage(argv[0]);
        return 1;
    }

    char flag = 0;
    if (parseFlag(argv[2], &flag) != ST_OK) {
        printf("Неизвестный флаг\n");
        printUsage(argv[0]);
        return 1;
    }

    long long x = 0;
    status_t st = parseLongLong(argv[1], &x);
    if (st == ST_ERR_OVERFLOW) {
        printf("Число не помещается в long long (переполнение)\n");
        return 1;
    }
    if (st != ST_OK) {
        printf("Неверный формат числа\n");
        return 1;
    }

    switch (flag) {
        case 'h': return runH(x);
        case 'p': return runP(x);
        case 's': return runS(x);
        case 'e': return runE(x);
        case 'a': return runA(x);
        case 'f': return runF(x);
        default:  return 1;
    }
}