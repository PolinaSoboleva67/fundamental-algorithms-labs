#include "functions.h"
#include <limits.h>

status_t getMultiplesOfX(long long x, int *out, size_t capacity, size_t *count)
{
    if (out == NULL || count == NULL) return ST_ERR_INVALID_INPUT;
    if (x <= 0)                       return ST_ERR_INVALID_INPUT;
    if (capacity < MULTIPLES_MAX)     return ST_ERR_INVALID_INPUT;

    *count = 0;
    for (int i = 1; i <= 100; ++i) {
        if (i % x == 0) out[(*count)++] = i;
    }
    return ST_OK;
}

status_t checkIfPrime(long long x, primality_t *out)
{
    if (out == NULL) return ST_ERR_INVALID_INPUT;

    if (x < 2) {
        *out = NUM_NEITHER_PRIME_NOR_COMPOSITE;
        return ST_OK;
    }

    for (long long i = 2; i <= x / i; ++i) {
        if (x % i == 0) {
            *out = NUM_COMPOSITE;
            return ST_OK;
        }
    }
    *out = NUM_PRIME;
    return ST_OK;
}

static char digitToHex(unsigned long long d)
{
    return (d < 10ULL) ? (char)('0' + d) : (char)('A' + (d - 10ULL));
}

status_t getHexDigits(long long x, char *out, size_t capacity, size_t *count, int *is_negative)
{
    if (out == NULL || count == NULL || is_negative == NULL)
        return ST_ERR_INVALID_INPUT;
    if (capacity < HEX_DIGITS_MAX)
        return ST_ERR_INVALID_INPUT;

    unsigned long long v = (x < 0)
        ? (0ULL - (unsigned long long)x)
        : (unsigned long long)x;

    char tmp[HEX_DIGITS_MAX];
    size_t n = 0;

    do {
        tmp[n++] = digitToHex(v & 0xFULL);
        v >>= 4;
    } while (v != 0 && n < HEX_DIGITS_MAX);

    for (size_t i = 0; i < n; ++i) {
        out[i] = tmp[n - 1 - i];
    }

    *count = n;
    *is_negative = (x < 0) ? 1 : 0;
    return ST_OK;
}

status_t getTableOfPowers(long long x, long long *out, size_t capacity, size_t *cols)
{
    if (out == NULL || cols == NULL) return ST_ERR_INVALID_INPUT;
    if (x < POWERS_BASE_MIN || x > POWERS_POW_MAX)
        return ST_ERR_INVALID_INPUT;
    if (capacity < (size_t)(POWERS_BASE_MAX - POWERS_BASE_MIN + 1) * (size_t)x)
        return ST_ERR_INVALID_INPUT;

    for (int base = POWERS_BASE_MIN; base <= POWERS_BASE_MAX; ++base) {
        long long num = base;
        for (int pw = 1; pw <= (int)x; ++pw) {
            out[(base - POWERS_BASE_MIN) * POWERS_POW_MAX + (pw - 1)] = num;
            num *= base;
        }
    }
    *cols = (size_t)x;
    return ST_OK;
}

status_t getSumOfSequence(long long x, long long *out)
{
    if (out == NULL) return ST_ERR_INVALID_INPUT;
    if (x < 1)       return ST_ERR_INVALID_INPUT;

    long long a, b;
    if (x % 2 == 0) {
        a = x / 2;
        b = x + 1;
    } else {
        a = (x + 1) / 2;
        b = x;
    }

    if (a != 0 && b > LLONG_MAX / a) return ST_ERR_OVERFLOW;

    *out = a * b;
    return ST_OK;
}

status_t getFactorial(long long x, long long *out)
{
    if (out == NULL) return ST_ERR_INVALID_INPUT;
    if (x < 0)       return ST_ERR_INVALID_INPUT;
    if (x > FACT_MAX_ARG) return ST_ERR_OVERFLOW;

    long long res = 1;
    for (long long i = 2; i <= x; ++i) res *= i;
    *out = res;
    return ST_OK;
}